package usetournament;

import java.util.Map;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

import fr.miage.tournament.Score;
import fr.miage.tournament.TournamentPackage;

public class LoadTournament {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		TournamentPackage.eINSTANCE.eClass();
		
		 
             // Initialize the model


             // Register the XMI resource factory for the .website extension

             Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
             Map<String, Object> m = reg.getExtensionToFactoryMap();
             m.put("tournament", new XMIResourceFactoryImpl());

             // Obtain a new resource set
             ResourceSet resSet = new ResourceSetImpl();

             // Get the resource
             Resource resource = resSet.getResource(URI
                             .createURI("models/tournoi.tournament"), true);
             // Get the first model element and cast it to the right type, in my
             // example everything is hierarchical included in this first node
             Score score = (Score) resource.getContents().get(0);
             System.out.println(score);

	}

}
