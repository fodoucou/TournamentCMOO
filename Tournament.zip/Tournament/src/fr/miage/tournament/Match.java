/**
 * Reserves � Miage
 */
package fr.miage.tournament;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Match</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.miage.tournament.Match#getEquipe1 <em>Equipe1</em>}</li>
 *   <li>{@link fr.miage.tournament.Match#getEquipe2 <em>Equipe2</em>}</li>
 *   <li>{@link fr.miage.tournament.Match#getNom <em>Nom</em>}</li>
 *   <li>{@link fr.miage.tournament.Match#getEquipes <em>Equipes</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.miage.tournament.TournamentPackage#getMatch()
 * @model
 * @generated
 */
public interface Match extends EObject {
	/**
	 * Returns the value of the '<em><b>Equipe1</b></em>' containment reference list.
	 * The list contents are of type {@link fr.miage.tournament.Joueur}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Equipe1</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Equipe1</em>' containment reference list.
	 * @see fr.miage.tournament.TournamentPackage#getMatch_Equipe1()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Joueur> getEquipe1();

	/**
	 * Returns the value of the '<em><b>Equipe2</b></em>' containment reference list.
	 * The list contents are of type {@link fr.miage.tournament.Joueur}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Equipe2</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Equipe2</em>' containment reference list.
	 * @see fr.miage.tournament.TournamentPackage#getMatch_Equipe2()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Joueur> getEquipe2();

	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see fr.miage.tournament.TournamentPackage#getMatch_Nom()
	 * @model required="true"
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link fr.miage.tournament.Match#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Equipes</b></em>' containment reference list.
	 * The list contents are of type {@link fr.miage.tournament.Equipe}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Equipes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Equipes</em>' containment reference list.
	 * @see fr.miage.tournament.TournamentPackage#getMatch_Equipes()
	 * @model containment="true" required="true"
	 * @generated
	 */
	EList<Equipe> getEquipes();

} // Match
