/**
 * Reserves � Miage
 */
package fr.miage.tournament;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Equipe</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link fr.miage.tournament.Equipe#getNom <em>Nom</em>}</li>
 *   <li>{@link fr.miage.tournament.Equipe#getJoueurs <em>Joueurs</em>}</li>
 * </ul>
 * </p>
 *
 * @see fr.miage.tournament.TournamentPackage#getEquipe()
 * @model
 * @generated
 */
public interface Equipe extends EObject {
	/**
	 * Returns the value of the '<em><b>Nom</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nom</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nom</em>' attribute.
	 * @see #setNom(String)
	 * @see fr.miage.tournament.TournamentPackage#getEquipe_Nom()
	 * @model required="true"
	 * @generated
	 */
	String getNom();

	/**
	 * Sets the value of the '{@link fr.miage.tournament.Equipe#getNom <em>Nom</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nom</em>' attribute.
	 * @see #getNom()
	 * @generated
	 */
	void setNom(String value);

	/**
	 * Returns the value of the '<em><b>Joueurs</b></em>' reference list.
	 * The list contents are of type {@link fr.miage.tournament.Joueur}.
	 * It is bidirectional and its opposite is '{@link fr.miage.tournament.Joueur#getEquipe <em>Equipe</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Joueurs</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Joueurs</em>' reference list.
	 * @see fr.miage.tournament.TournamentPackage#getEquipe_Joueurs()
	 * @see fr.miage.tournament.Joueur#getEquipe
	 * @model opposite="equipe" required="true"
	 * @generated
	 */
	EList<Joueur> getJoueurs();

} // Equipe
